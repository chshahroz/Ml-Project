# Language_Detection
A machine learning Project of 3 students of Riphah International University.
Introduction: 
Language Detection is Machine learning Project based on NLP (Natural Language Processing). It is used to identify the language of a given piece of text. This is an important task in NLP, especially for multilingual applications, where the language of a given text is not always known in advance. It works as multi-class classification by analyzing various features of the text, such as character set, word frequency, and n-grams, among others.
